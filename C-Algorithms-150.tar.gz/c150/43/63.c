# include "stdio.h"
main()
 { int i,j;
  printf("\l\l\n");
  for(i=1;i<11;i++)
   { for(j=1;j<=i;j++)
  printf("%c%c",219,219);
  printf("\n");
  }
  }
