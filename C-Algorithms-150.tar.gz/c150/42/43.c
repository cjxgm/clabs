# include "stdio.h"
main()
 { int i,j;
 char a,b;
 a=1;
 b=1;
 printf("%c\n%c\n",a,b);
  printf("\l\l\n");
  for(i=1;i<11;i++)
   { for(j=1;j<=i;j++)
  printf("%c%c",219,219);
  printf("\n");
  }
  }
