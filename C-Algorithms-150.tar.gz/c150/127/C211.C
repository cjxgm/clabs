main()
 {
   int i;
   clrscr();
   for(i=1;i<=41;i++)
   printf("*");
   printf("\n");
   printf("*	The results of calculation	*\n");
   printf("*	==========================	*\n");
   for(i=1;i<=41;i++)
   printf("*");
   }