 #include "stdio.h"
 #include "stdlib.h"                  /*Ӧ��atol��atof����*/
 #include "ctype.h"                   /*Ӧ��toupper����*/
 #define  N  50                       /*����¼��*/
 static int n=0;
 struct studinfo                      /*����ṹ��*/
    {
      char name[10];                  /*����*/
      long number;                    /*ѧ��*/
      char sex;                       /*�Ա�*/
      float score;                    /*�ɼ�*/
    }student[N];
 void new()                           /*������Ϣ*/
    {
      char numstr[10];
      printf("\n Input all data(name,number,sex(m/w),score)of studene[%d]:\n",n+1);
      gets(student[n].name);
      gets(numstr);
      student[n].number=atol(numstr);
      student[n].sex=getchar();
      getchar();
      gets(numstr);
      student[n].score=atof(numstr);
      n++;                             /*��¼����*/
    }
 void listone(int k,struct studinfo *s)/*���������¼*/
    {
      printf(" %6d \t %-12s \t %-8ld \t  %c \t %6.2f \n",k,s->name,s->number,s->sex,s->score);
    }
 void list()                           /*�����¼*/
    {
      int i;
      if(n<1)
          printf("\n There is not a student!");
      else
        {
	  printf("\n record \t name \t \t number \t sex \t score\n");
          for(i=0;i<n;i++)
             listone(i+1,&student[i]);
         }
     }
 main()
   {
     char ch;
     int  flag=1;
     while(flag==1)                      /*ͨ�������*/
        {
          printf("\n Input 'N' or 'n' to input new record,'L'' or 'l' to list all record:");
          ch=toupper(getchar());
          getchar();
          if(ch=='N')
            new();
          else if(ch=='L')
            list();
          else
            flag=0;
         }
      return;
    }     
   