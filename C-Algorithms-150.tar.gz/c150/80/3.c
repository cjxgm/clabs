main ( )
 {
   long  x,  y ;                
    x=1 ;   
    y=18;                  
    while ( y>0)             
     { x=2*(x+1) ;
       y-- ;
       }
    printf("x=%ld\n", x);      
