#ifndef _VWM_MODULES_H_
#define _VWM_MODULES_H_

#ifdef _VIPER_WIDE
#include <ncursesw/curses.h>
#else
#include <curses.h>
#endif

#include <glib.h>

#endif



