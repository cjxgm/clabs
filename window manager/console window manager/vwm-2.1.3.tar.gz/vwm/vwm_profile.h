#ifndef _VWM_PROFILE_H_
#define _VWM_PROFILE_H_

#include <glib.h>
#include <sys/types.h>



#endif

