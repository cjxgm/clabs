
#include <stdio.h>
#include <stdlib.h>
#include "DxLib.h"

int jmp_or_not()
{
	int i;
	for(i=0; i<=8; i++)
		if (CheckHitKey(SDLK_0+i))
			return i;
	return -1;
}

int main()
{
	DxLib_Init("DxLib Test Drive", 640, 480, 24);

	SetTransColor(0x99, 0xFF, 0XFF);
	int mg = LoadGraph("player.png");
	{
		int w, h;
		GetGraphSize(mg, &w, &h);
		printf("mg = (%dx%d)\n", w, h);
	}
	int gs[5] = {
		DerivationGraph(0, 0, 30, 36, mg),
		DerivationGraph(31*4, 0, 30, 36, mg),
		DerivationGraph(31*1, 0, 30, 36, mg),
		DerivationGraph(31*2, 0, 30, 36, mg),
		DerivationGraph(31*3, 0, 30, 36, mg),
	};

	WaitKey();

	int i, j, k=0;
	for (i=0; i<400 && !ProcessMessage(); i+=1){
		if (CheckHitKey(PAD_INPUT_RIGHT))
			i+=10;
		if (CheckHitKey(PAD_INPUT_LEFT))
			i-=10;
		if (CheckHitKey(PAD_INPUT_UP))
			k++;
		if (CheckHitKey(PAD_INPUT_DOWN))
			k--;
		k += 5;
		k %= 5;
		if (CheckHitKey(KEY_INPUT_ESCAPE))
			break;
		j = jmp_or_not();
		if (j != -1)
			i = j/8.0*300;
		ClearDrawScreen();
		DrawGraph(i,i,gs[k],0);
		ScreenFlip();
		WaitTimer(20);
	}

	DxLib_End();
	return 0;
}
