#include <stdlib.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <assert.h>
#include "DxLib.h"

#define true TRUE
#define false FALSE

static SDL_Surface *screen;
static bool key_buf[320] = {false};
static short bdepth = 32;
static byte trans_r = 0xFF;
static byte trans_g = 0xFF;
static byte trans_b = 0xFF;

int DxLib_Init(string title, int w, int h, int bitdepth)
{
	atexit(SDL_Quit);
	if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
		return -1;
	screen = SDL_SetVideoMode(w, h, bitdepth, SDL_HWSURFACE);
	bdepth = bitdepth;
	if (screen == NULL) return -1;
	SDL_WM_SetCaption(title, "");
}

inline void DxLib_End()
{
	SDL_Quit();
}

int ProcessMessage()
{
	SDL_Event event;
	while (SDL_PollEvent(&event)){
		switch (event.type){
		case SDL_QUIT:
			return 1;
		case SDL_KEYDOWN:
			key_buf[event.key.keysym.sym] = true;
			break;
		case SDL_KEYUP:
			key_buf[event.key.keysym.sym] = false;
			break;
		default:
			break;
		}
	}
	return 0;
}

inline void WaitTimer(int interval)
{
	SDL_Delay(interval);
}

inline void ScreenFlip()
{
	SDL_Flip(screen);
}

void DrawGraph(int x, int y, int graphid, int no_use)
{
	SDL_Surface *graph = (SDL_Surface*)graphid;
	SDL_Rect offset;

	offset.x = x;
	offset.y = y;

	SDL_BlitSurface(graph, NULL, screen, &offset);
}

inline int GetNowCount()
{
	return SDL_GetTicks();
}

int GetRand(int max)
{
	srand(GetNowCount());
	return (double)rand()/RAND_MAX*max;
}

inline uint GetColor(byte r, byte g, byte b)
{
	return r*256*256 + g*256 + b;
}

void WaitKey()
{
	SDL_Event event;

	for(;;){
		if (SDL_PollEvent(&event)){
			if (event.type == SDL_KEYDOWN)
				break;
			else if (event.type == SDL_QUIT){
				DxLib_End();
				exit(0);
			}
		}
	}
}

inline int CheckHitKey(int key) // return 1=>down; 0=>not down
{
	return key_buf[key];
}


inline void ClearDrawScreen(){
	SDL_FillRect(screen, &screen->clip_rect,
			SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
}


/************ loadg.c ****************/

void SetTransColor(byte r, byte g, byte b)
{
	trans_r = r;
	trans_g = g;
	trans_b = b;
}

int LoadGraph(string filename)
{
	// Load
	SDL_Surface *graph = IMG_Load(filename);
	assert(graph != NULL);

	// Optimize
	SDL_Surface *graph2 = SDL_DisplayFormat(graph);
	SDL_FreeSurface(graph);
	assert(graph2 != NULL);

	return (int)graph2;
}

int DerivationGraph(int x, int y, int w, int h, int graphid)
{
	SDL_Surface *graph = (SDL_Surface*) graphid;
	SDL_Surface *graph2 = SDL_CreateRGBSurface(
				SDL_HWSURFACE, w, h, bdepth, 0, 0, 0, 0);

	SDL_Rect rect;
	rect.x = x;
	rect.y = y;
	rect.w = w;
	rect.h = h;

	SDL_BlitSurface(graph, &rect, graph2, &graph2->clip_rect);

	// Transparent
	SDL_SetColorKey(graph2, SDL_SRCCOLORKEY,
			SDL_MapRGB(graph2->format, trans_r, trans_g, trans_b));

	return (int)graph2;
}

void GetGraphSize(int graphid, int *w, int *h)
{
	SDL_Surface *graph = (SDL_Surface*)graphid;
	*w = graph->clip_rect.w;
	*h = graph->clip_rect.h;
}
